import React, { useEffect, useState } from "react";
import {
  Form,
  Input,
  InputNumber,
  DatePicker,
  Select,
  Button,
  Row,
  Col,
  App,
} from "antd";
import type { DatePickerProps } from "antd";
import CompanySearchSelect from "../../components/general/CompanySearchSelect";
import MemberSelect from "../../components/general/MemberSelect";
import { CompanyOption, Quote } from "../../types/types";
import { useQuoteStore } from "../../store/useQuoteStore";
import { useNavigate, useParams } from "react-router-dom";
import dayjs from "dayjs";
import { debounce, throttle } from "lodash-es";
import { ProCard } from "@ant-design/pro-components";
import { MoneyInput } from "../../components/general/MoneyInput";
import AddressInput from "../../components/general/AddressInput";
import { CustomSelect } from "../../components/general/CustomSelect";
import QuoteItemsTable from "../../components/quote/QuoteItemsTable";
import TagAutoComplete from "../../components/general/TagAutoComplete";

const { Option } = Select;
const { TextArea } = Input;

const INDUSTRY = {
  新能源及储能: ["动力电池（锂电、氢燃料、钠电）", "光伏新能源"],
  半导体及电子元器件: ["半导体（泛半导体）", "先进封装", "高端显示"],
  消费电子: ["消费电子"],
  医疗及环保: ["医疗卫生", "环保行业"],
  工业制造及材料: ["新型建材", "包装行业"],
};

const QuoteFormPage = () => {
  const { id } = useParams<{ id: string }>();
  const { message } = App.useApp();
  const quoteId = parseInt(id ?? "");
  const navigate = useNavigate();
  const { fetchQuote, updateQuote, saveQuote } = useQuoteStore(); // Assuming your store has loading state

  const quote = useQuoteStore((state) =>
    state.quotes.find((quote) => quote.id == parseInt(id ?? "0"))
  );
  const [form] = Form.useForm<Quote & { customer: any }>();

  const onFinish = async () => {
    updateQuote(quoteId, { status: "completed" });
    await save();
  };

  // 提交失败（验证不通过）
  const onFinishFailed = ({ errorFields }: { errorFields: any }) => {
    if (errorFields.length > 0) {
      // 获取第一个错误的字段名和错误信息
      // console.log(errorFields);
      const firstError = errorFields[0];
      const errorMsg = firstError.errors[0];

      message.error(`${errorMsg}`);

      // （可选）自动滚动到错误字段（Ant Design 5+）
      // form.scrollToField(firstError.name);
    }
  };
  const save = throttle(
    async () => {
      await saveQuote(quoteId);
      message.success("保存成功");
    },
    5000,
    { leading: true, trailing: false } // 第一次立即执行，5秒内后续点击无效
  );

  const updateStore = debounce(
    (changedValues: Partial<Omit<Quote, "items">>) => {
      if (!id) return; // 新建时不自动保存

      const currentValues = form.getFieldsValue();
      if (changedValues.customerName) {
        const customer = changedValues.customerName as any;
        updateQuote(quoteId, {
          customerId: customer?.erpId,
          customerName: customer?.name,
        });
      } else if (
        !changedValues.quoteAmount &&
        !changedValues.totalProductPrice
      ) {
        useQuoteStore.getState().updateQuote(quoteId, {
          ...changedValues,
        });
      }
    },
    100
  );

  useEffect(() => {
    if (id && !quote) {
      const newQuote = fetchQuote(parseInt(id));
      if (!newQuote) {
        // 如果ID存在但找不到quote，跳转到错误页
        navigate("/error/no-permission", { replace: true });
        return;
      }
    }

    if (quote) {
      const { items, ...restQuote } = quote;

      form.setFieldsValue({
        ...restQuote,
        quoteTime: quote.quoteTime ? dayjs(quote.quoteTime) : null,
        customerName: {
          name: quote.customerName,
          value: quote.customerName,
          id: quote.customerId,
        } as any,
      });
    }
  }, [quote?.id]);

  const onDateChange: DatePickerProps["onChange"] = (date, dateString) => {
    form.setFieldsValue({ quoteTime: date?.toDate() });
  };

  return (
    <Form
      form={form}
      scrollToFirstError={{ behavior: "smooth", block: "nearest", focus: true }}
      layout="vertical"
      onFinish={onFinish}
      onFinishFailed={onFinishFailed}
      onValuesChange={updateStore}
      preserve={true}
    >
      <Row gutter={16}></Row>
      <ProCard
        title="基础信息"
        collapsible
        defaultCollapsed={false}
        style={{ marginBottom: 16 }}
        headerBordered
      >
        <Row gutter={16}>
          {quote?.type != "history" && (
            <Col xs={8} md={4}>
              <Form.Item
                name="quoteNumber"
                label="报价单编号"
                rules={[{ required: true, message: "请输入报价单编号" }]}
              >
                <Input
                  style={{ width: "100%" }}
                  readOnly={quote?.type != "history"}
                />
              </Form.Item>
            </Col>
          )}
          <Col xs={8} md={4}>
            <Form.Item
              name="orderId"
              label="订单编号"
              rules={[{ required: true, message: "订单编号" }]}
            >
              <Input
                style={{ width: "100%" }}
                readOnly={quote?.type != "history"}
              />
            </Form.Item>
          </Col>
          {quote?.type != "history" && (
            <Col xs={8} md={8}>
              <Form.Item name="opportunityName" label="商机名称">
                <Input readOnly />
              </Form.Item>
            </Col>
          )}

          <Col xs={12} md={8}>
            <Form.Item
              name="quoteName"
              label="报价单名称"
              rules={[{ required: true, message: "请输入报价单名称" }]}
            >
              <Input />
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={16}>
          <Col xs={12} md={8}>
            <Form.Item
              name="material"
              label="适用原料"
              rules={[{ required: true, message: "请填写适用原料" }]}
            >
              <TagAutoComplete />
            </Form.Item>
          </Col>
          <Col xs={12} md={8}>
            <Form.Item name="finalProduct" label="最终产品">
              <Select mode="tags" placeholder="请选择最终产品">
                {/* 这里可以添加预设的最终产品选项 */}
                <Option value="furniture">家具</Option>
                <Option value="electronics">电子产品</Option>
                <Option value="packaging">包装</Option>
              </Select>
            </Form.Item>
          </Col>
          <Col xs={12} md={8}>
            <Form.Item name="applicationField" label="应用领域">
              <CustomSelect
                mode="multiple"
                initialGroups={INDUSTRY}
                dropdown={false}
              />
            </Form.Item>
          </Col>
          <Col span={24}>
            <Form.Item
              name="产品明细"
              rules={[
                {
                  required: true,
                  validator: () => {
                    if (quote?.items.length == 0) {
                      return Promise.reject("请输入至少一条产品");
                    }
                    return Promise.resolve();
                  },
                },
                {
                  required: true,
                  validator: () => {
                    const index = quote?.items.findIndex(
                      (item) => !item.configCompleted
                    );
                    if (index != -1) {
                      return Promise.reject(
                        `第${index ?? 0 + 1}个产品产品配置未完成`
                      );
                    }
                    return Promise.resolve();
                  },
                },
              ]}
            >
              <QuoteItemsTable quoteId={quote?.id ?? 0} />
            </Form.Item>
          </Col>
        </Row>
      </ProCard>

      <ProCard
        title="报价单价格"
        collapsible
        defaultCollapsed={false}
        style={{ marginBottom: 16 }}
        headerBordered
      >
        <Row gutter={16}>
          <Col xs={12} md={6}>
            <Form.Item label="产品价格合计">
              <MoneyInput
                quoteId={quoteId}
                value={quote?.totalProductPrice ?? 0}
                readOnly
              />
            </Form.Item>
          </Col>
          <Col xs={12} md={6}>
            <Form.Item
              name="discountAmount"
              label="优惠金额"
              normalize={(value) => parseFloat(value)}
            >
              <MoneyInput quoteId={quoteId} />
            </Form.Item>
          </Col>
          <Col xs={12} md={6}>
            <Form.Item label="报价单金额">
              <MoneyInput
                quoteId={quoteId}
                value={quote?.quoteAmount ?? 0}
                readOnly
              />
            </Form.Item>
          </Col>
          <Col xs={12} md={6}>
            <Form.Item
              name="deliveryDays"
              label="交期天数"
              rules={[{ required: true, message: "请输入交期天数" }]}
            >
              <InputNumber
                style={{ width: "100%" }}
                min={0}
                max={365}
                formatter={(value) => `${value}天`}
                controls={false}
                parser={(value) => {
                  const num = Number(value?.replace("天", "") || 0);
                  return Math.min(Math.max(num, 0), 365) as any; // 确保在0-365范围内
                }}
              />
            </Form.Item>
          </Col>
        </Row>
      </ProCard>

      <ProCard
        title="联系信息"
        collapsible
        defaultCollapsed={false}
        style={{ marginBottom: 16 }}
        headerBordered
      >
        <Row gutter={16}>
          <Col xs={12} md={8}>
            <Form.Item
              name="customerName"
              label="客户选择"
              rules={[{ required: true, message: "请选择客户" }]}
            >
              <CompanySearchSelect placeholder="请选择客户" />
            </Form.Item>
          </Col>
          <Col xs={12} md={8}>
            <Form.Item
              name="contactName"
              label="联系人姓名"
              rules={[{ required: true, message: "请输入联系人姓名" }]}
            >
              <Input />
            </Form.Item>
          </Col>

          <Col xs={12} md={8}>
            <Form.Item
              name="contactPhone"
              label="联系人手机号"
              rules={[{ required: true, message: "请输入联系人手机号" }]}
            >
              <Input />
            </Form.Item>
          </Col>
          <Col xs={24} md={24}>
            <Form.Item name="address" label="地址">
              <AddressInput />
            </Form.Item>
          </Col>
        </Row>
      </ProCard>

      <ProCard
        title="负责人信息"
        collapsible
        defaultCollapsed={false}
        style={{ marginBottom: 16 }}
        headerBordered
      >
        <Row gutter={16}>
          <Col xs={12} md={6}>
            <Form.Item
              name="creatorId"
              label="创建人"
              rules={[{ required: true, message: "请选择创建人" }]}
            >
              <MemberSelect placeholder="选择创建人" disabled />
            </Form.Item>
          </Col>
          <Col xs={12} md={6}>
            <Form.Item
              name="chargerId"
              label="负责人"
              rules={[{ required: true, message: "请选择负责人" }]}
            >
              <MemberSelect placeholder="选择负责人" />
            </Form.Item>
          </Col>
          <Col xs={12} md={6}>
            <Form.Item name="projectManagerId" label="项目管理">
              <MemberSelect placeholder="选择项目管理" />
            </Form.Item>
          </Col>
          <Col xs={12} md={6}>
            <Form.Item name="salesSupportId" label="销售支持">
              <MemberSelect placeholder="选择销售支持" />
            </Form.Item>
          </Col>
          <Col xs={12} md={6}>
            <Form.Item
              name="quoteTime"
              label="报价时间"
              rules={[{ required: true, message: "请选择报价时间" }]}
            >
              <DatePicker
                style={{ width: "100%" }}
                onChange={onDateChange}
                maxDate={dayjs("2025/5/1")}
              />
            </Form.Item>
          </Col>
        </Row>
      </ProCard>

      <Row>
        <Col span={24} style={{ textAlign: "right" }}>
          <Button type="primary" htmlType="submit">
            提交
          </Button>
          <Button style={{ marginLeft: 8 }} onClick={save}>
            暂存
          </Button>
        </Col>
      </Row>
    </Form>
  );
};

export default QuoteFormPage;

import { Tabs, Typography } from "antd";
import { FormInstance } from "antd/lib";
import {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from "react";
import PriceForm from "./PriceForm";
import DieForm from "../../quoteForm/dieForm/DieForm";
import { OtherForm } from "./OtherForm";
import SmartRegulator from "../../quoteForm/SmartRegulator";
import { QuoteItem } from "../../../types/types";

interface ProductConfigurationFormProps {
  quoteItem?: QuoteItem;
  quoteId: number;
}
const ProductConfigurationForm = forwardRef(
  ({ quoteItem, quoteId }: ProductConfigurationFormProps, ref) => {
    const priceFormRef = useRef<{ form: FormInstance }>(null);
    const dieFormRef = useRef<{ form: FormInstance }>(null);
    const smartRegulatorFormRef = useRef<{ form: FormInstance }>(null);
    const infoFormRef = useRef<{ form: FormInstance }>(null);
    const [activeKey, setActiveKey] = useState("1");
    // 暴露priceForm给祖父组件
    useImperativeHandle(ref, () => ({
      priceForm: priceFormRef?.current?.form,
      dieForm: dieFormRef?.current?.form,
      smartRegulatorFormRef: smartRegulatorFormRef?.current?.form,
      infoForm: infoFormRef?.current?.form,
      switchTab: (key: string) => setActiveKey(key),
    }));

    const setForm = () => {
      const category = quoteItem?.productCategory;
      if (category?.[0] == "平模")
        return (
          <DieForm
            quoteItemId={quoteItem?.id ?? 0}
            quoteId={quoteId}
            ref={dieFormRef}
          />
        );
      if (category?.[1] == "智能调节器")
        return <SmartRegulator ref={smartRegulatorFormRef} />;

      return <OtherForm ref={infoFormRef} />;
    };

    return (
      <Tabs
        centered
        activeKey={activeKey}
        onChange={setActiveKey}
        defaultActiveKey="1"
        // destroyInactiveTabPane={false}
        items={[
          {
            label: "规格配置",
            key: "1",
            children: setForm(),
            forceRender: true,
          },
          {
            label: "价格配置",
            key: "2",
            children: <PriceForm ref={priceFormRef} />,
            forceRender: true,
          },
        ]}
      />
    );
  }
);
export default ProductConfigurationForm;

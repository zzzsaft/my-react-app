export const MATERIAL = {
  高粘度: ["PEEK", "PC", "PET", "PMMA", "PVC", "PES-P", "PES-T", "PVB"],
  中粘度: ["ABS", "HIPS", "GPPS", "PP", "PETG", "PLA"],
  低粘度: ["LDPE", "LLDPE", "HDPE", "EVA", "POE", "TPE"],
};

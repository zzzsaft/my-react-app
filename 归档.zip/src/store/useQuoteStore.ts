// store/useQuoteStore.ts
import { create } from "zustand";
import { nanoid } from "nanoid";
import { message } from "antd";
import { OpportunityService } from "../api/services/opportunity.service";
import { isEqual } from "lodash-es";
import { produce } from "immer";
import zukeeper from "zukeeper";
import { values } from "lodash";
import { ProductCategory, Quote, QuoteItem } from "../types/types";
import { immer } from "zustand/middleware/immer";
import { QuoteService } from "../api/services/quote.service";
import { insertAfter } from "../util/valueUtil";

export interface Customer {
  id: string;
  name: string;
  charger?: string;
  collaborator?: string[];
}

export interface Contact {
  name: string;
  phone?: string;
}
export interface Opportunity {
  customer: Customer;
  id: string;
  name: string;
  latestQuoteStatus: "none" | "quoting" | "reviewing" | "completed";
  quoteCount: number;
  charger: string;
  chargerId: string;
  createdAt: string;
  lastQuoteDate?: string;
  products: ProductInfo[];
}
export interface ProductInfo {
  productName: string;
  productCategory: string[];
  price: number;
  quantity: number;
}
export interface Product {
  id: string;
  name: string;
  category: string[];
  basePrice: number;
  configSchema?: any; // JSON Schema for product configuration
}

interface QuotesStore {
  quotes: Quote[];
  loading: boolean;
  categories: ProductCategory[];
  configModalVisible: boolean;
  setConfigModalVisible: (bool: boolean) => void;
  initialize: () => Promise<void>;
  fetchCategories: () => Promise<void>;
  fetchQuotes: () => Promise<void>;
  fetchQuote: (quoteId: number) => Promise<Quote>;
  createQuote: (params: {
    customerName: string;
    customerId: string;
    quoteId?: string;
    orderId?: string;
    date: Date;
    chargerId: string;
    projectManagerId: string;
    quoteName: string;
  }) => Promise<void>;
  updateQuote: (
    quoteId: number,
    updateData: Partial<Omit<Quote, "items">>
  ) => void;
  addQuoteItem: (quoteId: number, item?: Partial<QuoteItem>) => Promise<number>;
  addChildQuoteItem: (
    quoteId: number,
    parentId: number,
    item: Partial<QuoteItem>
  ) => void;
  deleteQuoteItem: (quoteId: number, itemId: number) => Promise<void>;
  updateQuoteItem: (
    quoteId: number,
    itemId: number | null,
    updateData: Partial<QuoteItem>
  ) => void;
  updateQuoteItemConfig: (
    quoteId: number,
    itemId: number | null,
    updateConfig: any
  ) => void;
  setQuoteItem: (quoteId: number, items: QuoteItem[]) => void;
  saveQuote: (quoteId: number) => Promise<void>;
  findItemById: (
    items: QuoteItem[],
    itemId: number | null
  ) => QuoteItem | undefined;
  findItemParent: (
    items: QuoteItem[],
    itemId: number | null
  ) => { parent: QuoteItem | undefined; index: number } | undefined;
  calculateItemPrice: (item: QuoteItem) => void;
  // calculateQuoteTotal: (quoteId: number) => void;
}

export const useQuoteStore = create<QuotesStore>()(
  immer((set, get) => ({
    quotes: [],
    categories: [],
    loading: false,
    configModalVisible: false,

    setConfigModalVisible: (bool) => {
      set({ configModalVisible: bool });
    },

    initialize: async () => {
      const categories = await OpportunityService.getProductCategory();
      set({ categories });
    },

    fetchQuotes: async () => {
      set({ loading: true });
      const quotes = await QuoteService.getQuotes();
      set({ quotes, loading: false });
    },

    fetchQuote: async (quoteId) => {
      try {
        const newQuote = await QuoteService.getQuote(quoteId);

        set((state) => {
          // 检查是否已存在相同quoteId的报价
          const existingIndex = state.quotes.findIndex(
            (q) => q.quoteId === newQuote.quoteId
          );

          if (existingIndex >= 0) {
            // 如果存在则更新
            state.quotes[existingIndex] = newQuote;
          } else {
            // 如果不存在则添加
            state.quotes.push(newQuote);
          }
        });
        return newQuote;
      } catch (error) {
        console.error("获取报价失败:", error);
        throw error; // 可以选择重新抛出错误或在UI层处理
      }
    },

    fetchCategories: async () => {
      const categories = await OpportunityService.getProductCategory();
      set({ categories });
    },

    createQuote: async (params) => {
      const quote = await QuoteService.createQuote({
        ...params,
        type: "history",
        status: "draft",
      });
      set((state) => {
        state.quotes.push(quote);
      });
    },

    updateQuote: async (quoteId, updateData) => {
      set((state) => {
        const quote = state.quotes.find((q) => q.id === quoteId);
        if (quote) {
          Object.assign(quote, updateData);
          if (updateData.discountAmount != null) {
            calculateQuoteTotal(quote);
          }
        }
      });
    },

    addQuoteItem: async (quoteId, item) => {
      try {
        set({ loading: true });

        // 1. 获取当前 quote 和 items 长度
        const state = get();
        const quote = state.quotes.find((q) => q.id === quoteId);
        if (!quote) throw new Error(`Quote ${quoteId} not found`);

        const currentLength = quote.items.length;

        // 2. 调用 API 创建新 item
        const quoteItem: QuoteItem = await QuoteService.createQuoteItem(
          quoteId,
          null,
          {
            ...item,
            index: currentLength + 1, // 初始索引
          }
        );

        // 3. 使用 Immer 更新状态
        set((state) => {
          const quote = state.quotes.find((q) => q.id === quoteId);
          if (!quote) return state;

          // 查找目标位置（假设用 linkId 匹配）
          const targetIndex = quote.items.findIndex(
            (i) => i.id === quoteItem.linkId
          );

          // 插入或追加
          if (targetIndex !== -1) {
            quote.items.splice(targetIndex + 1, 0, {
              ...quoteItem,
              index: targetIndex + 2, // 直接计算新 index
            });
            // 仅更新后续元素的 index（避免全量遍历）
            for (let i = targetIndex + 2; i < quote.items.length; i++) {
              quote.items[i].index = i + 1;
            }
          } else {
            quote.items.push({
              ...quoteItem,
              index: currentLength + 1,
            });
          }

          state.loading = false;
        });

        return quoteItem.id;
      } catch (error) {
        set({ loading: false });
        throw error; // 抛出错误供调用方处理
      }
    },

    addChildQuoteItem: async (quoteId, parentId, item) => {
      const quoteItem = await QuoteService.createQuoteItem(
        quoteId,
        parentId,
        item
      );
      set((state) => {
        const quote = state.quotes.find((q) => q.id === quoteId);
        if (quote) {
          const parentItem = get().findItemById(quote.items, parentId);
          if (parentItem) {
            if (!parentItem.children) {
              parentItem.children = [];
            }
            parentItem.children.push(quoteItem);
          }
        }
      });
    },

    deleteQuoteItem: async (quoteId, itemId) => {
      await QuoteService.deleteQuoteItem(itemId);
      set((state) => {
        const quote = state.quotes.find((q) => q.id === quoteId);
        if (quote) {
          // First try to find in top-level items
          const index = quote.items.findIndex((item) => item.id === itemId);
          if (index !== -1) {
            quote.items.splice(index, 1);
            calculateQuoteTotal(quote);
            return;
          }

          // If not found in top-level, search in children
          const parentInfo = get().findItemParent(quote.items, itemId);
          if (parentInfo && parentInfo.parent?.children) {
            parentInfo.parent.children.splice(parentInfo.index, 1);
            calculateQuoteTotal(quote);
          }
        }
      });
    },

    updateQuoteItem: (quoteId, itemId, updateData) => {
      set((state) => {
        const quote = state.quotes.find((q) => q.id === quoteId);
        if (quote) {
          const item = get().findItemById(quote.items, itemId);
          if (item) {
            Object.assign(item, updateData);
            get().calculateItemPrice(item);
            calculateQuoteTotal(quote);
          }
        }
      });
    },
    updateQuoteItemConfig: (quoteId, itemId, updateData) => {
      set((state) => {
        const quote = state.quotes.find((q) => q.id === quoteId);
        if (quote) {
          const item = get().findItemById(quote.items, itemId);
          if (item) {
            item.config = { ...(item.config ?? []), ...updateData };
          }
        }
      });
    },
    setQuoteItem: (quoteId: number, items: QuoteItem[]) => {
      set((state) => {
        const quote = state.quotes.find((q) => q.id === quoteId);
        if (quote?.items) {
          quote.items = items;
        }
      });
    },
    // Helper function to find item by ID (searches recursively in children)
    findItemById: (items, itemId) => {
      for (const item of items) {
        if (item.id === itemId) return item;
        if (item.children) {
          const found = get().findItemById(item.children, itemId);
          if (found) return found;
        }
      }
      return undefined;
    },

    // Helper function to find parent of an item
    findItemParent: (items, itemId) => {
      for (let i = 0; i < items.length; i++) {
        const item = items[i];
        if (item.children) {
          const childIndex = item.children.findIndex(
            (child) => child.id === itemId
          );
          if (childIndex !== -1) {
            return { parent: item, index: childIndex };
          }

          const foundInChildren = get().findItemParent(item.children, itemId);
          if (foundInChildren) return foundInChildren;
        }
      }
      return undefined;
    },
    saveQuote: async (quoteId) => {
      const quote = get().quotes.find((quote) => quoteId == quote.id);
      console.log(quote);
      if (quote) {
        await QuoteService.updateQuoteItem(quote);
      }
    },

    // 计算单个QuoteItem的价格
    calculateItemPrice: (item) => {
      if (item.unitPrice !== null && item.quantity !== null) {
        const basePrice = item.unitPrice * item.quantity;
        item.subtotal = (basePrice * (item.discountRate ?? 0)) / 100;
      }
    },
  }))
);
(window as any).store = useQuoteStore;
function calculateQuoteTotal(quote: Quote) {
  if (!quote) return;

  let totalProductPrice = 0;
  quote.items.forEach((item) => {
    if (item.subtotal !== null) {
      totalProductPrice += parseFloat(item.subtotal as any);
    }
  });

  quote.totalProductPrice = totalProductPrice || 0;
  quote.quoteAmount = totalProductPrice - (quote.discountAmount || 0);
}
